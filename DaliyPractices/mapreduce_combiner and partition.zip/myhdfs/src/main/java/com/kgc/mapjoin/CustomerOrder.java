package com.kgc.mapjoin;

import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by Administrator on 2019/7/10 0010.
 */
public class CustomerOrder implements Writable{
    private String customeId;
    private String customName;
    private String orderId;
    private String orderStatus;
    private String flag;

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeUTF(customeId);
        dataOutput.writeUTF(customName);
        dataOutput.writeUTF(orderId);
        dataOutput.writeUTF(orderStatus);
        dataOutput.writeUTF(flag);

    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        customeId = dataInput.readUTF();
        customName = dataInput.readUTF();
        orderId = dataInput.readUTF();
        orderStatus = dataInput.readUTF();
        flag = dataInput.readUTF();
    }

    public CustomerOrder() {
    }

    public CustomerOrder(String customeId, String customName, String orderId, String orderStatus, String flag) {
        this.customeId = customeId;
        this.customName = customName;
        this.orderId = orderId;
        this.orderStatus = orderStatus;
        this.flag = flag;
    }

    @Override
    public String toString() {
        return
                "\t" + customeId +
                "\t" + customName +
                "\t" + orderStatus ;
    }

    public String getCustomeId() {
        return customeId;
    }

    public void setCustomeId(String customeId) {
        this.customeId = customeId;
    }

    public String getCustomName() {
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}
