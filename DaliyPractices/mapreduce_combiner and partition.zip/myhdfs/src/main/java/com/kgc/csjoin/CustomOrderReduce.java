package com.kgc.csjoin;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2019/7/10 0010.
 */
public class CustomOrderReduce extends Reducer<Text,CustomerOrder,CustomerOrder,NullWritable> {

    @Override
    protected void reduce(Text key, Iterable<CustomerOrder> values, Context context) throws IOException, InterruptedException {
        CustomerOrder cus= new CustomerOrder();
        List<CustomerOrder> orders = new ArrayList<CustomerOrder>();
        try {
            for (CustomerOrder ord:values){
                CustomerOrder co = new CustomerOrder();
                if("1".equals(ord.getFlag())){
                    BeanUtils.copyProperties(co,ord);
                    orders.add(co);
                }else{
                    BeanUtils.copyProperties(cus,ord);
                }
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        for(CustomerOrder o:orders){
            o.setCustomName(cus.getCustomName());
            context.write(o,NullWritable.get());
        }
    }
}
