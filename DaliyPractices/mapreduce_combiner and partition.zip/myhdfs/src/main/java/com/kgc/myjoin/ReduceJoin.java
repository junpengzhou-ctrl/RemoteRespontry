package com.kgc.myjoin;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


import java.io.IOException;

/**
 * Created by Administrator on 2019/7/5 0005.
 * Reduce Join
 * 两表数据整合
 */
public class ReduceJoin extends Reducer<Text,Text,Text,Text> {
    Text coVal = new Text();
    String customer="",order="";
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        customer = order ="";
        for (Text value:values){
            String s=value.toString();
            if(s.startsWith("001")){
                customer =s;
            }else{
                order = s;
            }
        }
        coVal.set(customer+";"+order);
        context.write(key,coVal);

    }
}
