package com.kgc.temp2;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Temp2Mapper extends Mapper<LongWritable, Text,Text,MyTemp> {
    Text rkey = new Text();
    MyTemp mt = new MyTemp();
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String [] infos = value.toString().split("\t");//[1999-9-9,38c]
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        try {
            cal.setTime(sdf.parse(infos[0]));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        mt.setYear(cal.get(Calendar.YEAR));
        mt.setMonth(cal.get(Calendar.MONTH)+1);
        mt.setDay(cal.get(Calendar.DAY_OF_MONTH));
        int wd = Integer.parseInt(infos[1].substring(0,infos[1].length()-1));
        mt.setTemp(wd);
        rkey.set(infos[0]);
        context.write(rkey,mt);
    }
}
