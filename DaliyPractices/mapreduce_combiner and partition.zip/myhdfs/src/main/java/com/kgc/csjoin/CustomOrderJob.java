package com.kgc.csjoin;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;

/**
 * Created by Administrator on 2019/7/10 0010.
 */
public class CustomOrderJob {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf);
        job.setJarByClass(CustomOrderJob.class);
        job.setMapperClass(CustomOrderMapper.class);
        job.setReducerClass(CustomOrderReduce.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(CustomerOrder.class);
        job.setOutputKeyClass(CustomerOrder.class);
        job.setOutputValueClass(NullWritable.class);
        FileInputFormat.addInputPath(job,new Path("d:/source/customers.csv"));
        FileInputFormat.addInputPath(job,new Path("d:/source/orders.csv"));
        Path op = new Path("d:/source/res");
        if(op.getFileSystem(conf).exists(op)){
            op.getFileSystem(conf).delete(op,true);
        }
        FileOutputFormat.setOutputPath(job,new Path("d:/source/res"));
        job.waitForCompletion(true);
    }
}
