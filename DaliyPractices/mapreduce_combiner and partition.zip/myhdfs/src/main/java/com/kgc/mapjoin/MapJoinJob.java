package com.kgc.mapjoin;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;


/**
 * Created by Administrator on 2019/7/10 0010.
 */
public class MapJoinJob {
    public static void main(String[] args) throws IOException, URISyntaxException, ClassNotFoundException, InterruptedException {
        Configuration configuration = new Configuration();
        Job job = Job.getInstance(configuration);
        job.setJarByClass(MapJoinJob.class);
        job.setMapperClass(MapJoinMapper.class);

        job.setMapOutputKeyClass(CustomerOrder.class);
        job.setMapOutputValueClass(NullWritable.class);
        FileInputFormat.addInputPath(job,new Path("d:/source/orders.csv"));
        Path op = new Path("d:/source/res1");
        if(op.getFileSystem(configuration).exists(op)){
            op.getFileSystem(configuration).delete(op,true);
        }
        FileOutputFormat.setOutputPath(job,op);
       // DistributedCache.addCacheFile(new Path("d:/customers.csv").toUri(),configuration);
        job.addCacheFile(new Path("d:/customers.csv").toUri());
       // System.out.println(new URI("file:/d:/customers.csv"));
        job.setNumReduceTasks(0);
        job.waitForCompletion(true);
      //  System.out.println(new URI(new Path("d:/source/customers.csv").toString().substring(0)));
    }
}
