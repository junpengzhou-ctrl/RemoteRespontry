package com.kgc.tel;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/**
 * Created by Administrator on 2019/7/8 0008.
 */
public class TelMapper extends Mapper<LongWritable,Text,Text,TelWriter> {

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String [] infos = value.toString().split("\t");
        for (int i=0;i<infos.length;i++) {
            Text outkey = new Text(infos[0]);
            TelWriter tw = new TelWriter(Long.parseLong(infos[7]),Long.parseLong(infos[8]),Long.parseLong(infos[7])+Long.parseLong(infos[8]));
            context.write(outkey,tw);
        }
    }
}
