package com.kgc.mapjoin;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2019/7/10 0010.
 */
public class MapJoinMapper extends Mapper<LongWritable,Text,CustomerOrder,NullWritable> {
    Map<String,String> custMap = new HashMap<String,String>();
    CustomerOrder cust = new CustomerOrder();
    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        URI[] cacheFile = context.getCacheFiles();
        if(null != cacheFile && cacheFile.length>0){
            String path = cacheFile[0].getPath();
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
            String line;
            while(StringUtils.isNotEmpty(line = br.readLine())){
                String[] fields = line.split(",");
                custMap.put(fields[0],fields[1]);
            }
            br.close();
        }
    }

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] split = value.toString().split(",");
        cust.setOrderId(split[0]);
        cust.setOrderStatus(split[3]);
        cust.setCustomeId(split[2]);
        cust.setFlag("");
        cust.setCustomName(custMap.get(cust.getCustomeId()));
        context.write(cust,NullWritable.get());
    }
}
