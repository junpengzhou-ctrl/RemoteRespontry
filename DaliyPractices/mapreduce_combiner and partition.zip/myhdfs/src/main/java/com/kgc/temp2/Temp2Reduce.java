package com.kgc.temp2;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

public class Temp2Reduce extends Reducer<Text,MyTemp,Text,MyTemp> {
    List<MyTemp> mts = new ArrayList<MyTemp>();
    @Override
    protected void reduce(Text key, Iterable<MyTemp> values, Context context) throws IOException, InterruptedException {
        //key 1992-5
        try {
            for (MyTemp mt:values){
                MyTemp m = new MyTemp();
                BeanUtils.copyProperties(m,mt);
                mts.add(m);
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        //数组排序
        int len = mts.size();
        for(int row=0;row<len;row++){
            for(int col=0;col<len-row;col++){
                if(mts.get(col).compareTo(mts.get(col+1))==0){
                    MyTemp temp = mts.get(col);
                    mts.set(col,mts.get(col+1));
                    mts.set(col+1,temp);
                }
            }

        }

        //输出
        for(int i=0;i<2;i++){
            context.write(key,mts.get(i));
        }
    }
}
