package com.kgc.temp2;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

//清洗数据
public class Temp2Combiner extends Reducer<Text,MyTemp,Text,MyTemp> {
    MyTemp high = new MyTemp();
    Text rkey = new Text();
    @Override
    protected void reduce(Text key, Iterable<MyTemp> values, Context context) throws IOException, InterruptedException {
        //key 1992-5-6
        for (MyTemp mt:values){
            if(mt.getTemp()>high.getTemp()){
                high.setTemp(mt.getTemp());
            }
        }
        rkey.set(high.getYear()+"-"+(high.getMonth()+1));//1992-5
        context.write(rkey,high);
    }
}
