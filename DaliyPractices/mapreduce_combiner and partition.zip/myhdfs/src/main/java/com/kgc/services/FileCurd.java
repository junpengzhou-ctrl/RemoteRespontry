package com.kgc.services;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import sun.nio.ch.IOUtil;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;

/**
 * Created by Administrator on 2019/7/4 0004.
 */
public class FileCurd {
    public static void main(String[] args) throws Exception{
        FileSystem fs = FileSystem.get(new URI("hdfs://192.168.56.10:9000"), new Configuration(),"cmhd");
        InputStream is = new FileInputStream("e:/a.txt");
        OutputStream os = fs.create(new Path("/hadoop/a.txt"));
        IOUtils.copyBytes(is,os,4096,true);
    }
}
