package com.kgc.temp;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * Created by Administrator on 2019/7/9 0009.
 */
public class TQReduce extends Reducer<TQ,IntWritable,Text,NullWritable> {
    Text rkey = new Text();

    @Override
    protected void reduce(TQ key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
        int flg=0;
        int day = 0;
        for (IntWritable v:values) {
            if(flg==0 ){
                rkey.set(key.toString());
                day = key.getDay();
                flg++;
                context.write(rkey,NullWritable.get());
            }
            if(flg!=0 && day != key.getDay()){
                rkey.set(key.toString());
                context.write(rkey,NullWritable.get());
                break;
            }
        }
    }
}
