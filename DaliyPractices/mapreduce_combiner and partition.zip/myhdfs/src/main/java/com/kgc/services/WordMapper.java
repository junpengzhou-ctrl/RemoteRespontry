package com.kgc.services;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/**
 * Created by Administrator on 2019/7/4 0004.
 */
public class WordMapper extends Mapper<LongWritable,Text,Text,LongWritable> {
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        System.out.println(key.toString());
        String [] words = value.toString().split(" ");
        for (String word:words) {
            context.write(new Text(word),new LongWritable(1));
        }
    }
}
