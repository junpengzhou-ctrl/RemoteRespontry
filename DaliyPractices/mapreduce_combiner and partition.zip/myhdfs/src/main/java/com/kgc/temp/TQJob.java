package com.kgc.temp;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;

/**
 * Created by Administrator on 2019/7/9 0009.
 */
public class TQJob {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf);
        job.setJarByClass(TQJob.class);

        job.setMapperClass(TQMapper.class);
        job.setMapOutputKeyClass(TQ.class);
        job.setMapOutputValueClass(IntWritable.class);

        job.setPartitionerClass(TPartitioner.class);
        job.setSortComparatorClass(TSortComparator.class);

        job.setGroupingComparatorClass(TGroupingComparator.class);
        job.setReducerClass(TQReduce.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);

        FileInputFormat.addInputPath(job,new Path("d:/tq/tq.txt"));
        Path opath = new Path("d:/tq/res");
        if(opath.getFileSystem(conf).exists(opath)){
            opath.getFileSystem(conf).delete(opath,true);
        }
        FileOutputFormat.setOutputPath(job,opath);
        job.setNumReduceTasks(2);
        job.waitForCompletion(true);
    }
}
