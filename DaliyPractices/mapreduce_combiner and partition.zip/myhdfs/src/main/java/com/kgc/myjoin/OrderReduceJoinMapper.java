package com.kgc.myjoin;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/**
 * Created by Administrator on 2019/7/5 0005.
 */
public class OrderReduceJoinMapper extends Mapper<LongWritable,Text,Text,Text> {
    Text customid= new Text();
    Text order = new Text();
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String  [] datas = value.toString().split(",",-1);
        customid.set(datas[1]);
        order.set("002"+value.toString());
        context.write(customid,order);
    }
}
