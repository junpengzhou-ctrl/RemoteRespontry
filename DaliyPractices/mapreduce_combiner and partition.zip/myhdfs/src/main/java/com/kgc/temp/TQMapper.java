package com.kgc.temp;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Administrator on 2019/7/9 0009.
 */
public class TQMapper extends Mapper<LongWritable,Text,TQ,IntWritable> {
    TQ tq = new TQ();
    IntWritable iw = new IntWritable();
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

//        "1999-5-08 7:21:33  32C"
        try {
            String [] tqinfo = value.toString().split("\t");
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date date = sdf.parse(tqinfo[0]);
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            tq.setYear(cal.get(Calendar.YEAR));
            tq.setMonth(cal.get(Calendar.MONTH)+1);
            tq.setDay(cal.get(Calendar.DAY_OF_MONTH));
            int wd = Integer.parseInt(tqinfo[1].substring(0,tqinfo[1].length()-1));
            tq.setTemp(wd);

            iw.set(wd);

            context.write(tq,iw);
        } catch (ParseException e) {
            e.printStackTrace();
        }


    }
}
