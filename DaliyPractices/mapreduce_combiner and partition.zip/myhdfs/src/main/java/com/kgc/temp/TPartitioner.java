package com.kgc.temp;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Partitioner;

/**
 * Created by Administrator on 2019/7/9 0009.
 */
public class TPartitioner extends Partitioner<TQ,IntWritable>{
    @Override
    public int getPartition(TQ tq, IntWritable intWritable, int i)
    {
        int val = tq.getYear()%i;
        System.out.println(val+","+i);
        return val;
    }
}
