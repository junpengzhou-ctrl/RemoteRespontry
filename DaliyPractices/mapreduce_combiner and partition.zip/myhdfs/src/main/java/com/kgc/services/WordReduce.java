package com.kgc.services;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * Created by Administrator on 2019/7/4 0004.
 */
public class WordReduce extends Reducer<Text,LongWritable,Text,LongWritable> {
    @Override
    protected void reduce(Text key, Iterable<LongWritable> values, Context context) throws IOException, InterruptedException {
        long count=0L;
        for (LongWritable lw:values){
            count+=lw.get();
        }
        context.write(key,new LongWritable(count));
    }
}
