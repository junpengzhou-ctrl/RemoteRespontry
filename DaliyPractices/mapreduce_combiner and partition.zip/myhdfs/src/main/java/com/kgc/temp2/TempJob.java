package com.kgc.temp2;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;


public class TempJob {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
        Configuration conf= new Configuration();
        Job job = Job.getInstance(conf);
        job.setJarByClass(TempJob.class);

        job.setMapperClass(Temp2Mapper.class);//out: 1992-5-10 obj //按天分组
        job.setCombinerClass(Temp2Combiner.class);//out: 1992-5 obj //去重复 按月分组
        job.setReducerClass(Temp2Reduce.class);//out:xx obj

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(MyTemp.class);

        FileInputFormat.setInputPaths(job,new Path(""));
        Path outPath = new Path("");
        if(outPath.getFileSystem(conf).exists(outPath)){
            outPath.getFileSystem(conf).delete(outPath,true);
        }
        FileOutputFormat.setOutputPath(job,outPath);
        job.waitForCompletion(true);
    }
}
