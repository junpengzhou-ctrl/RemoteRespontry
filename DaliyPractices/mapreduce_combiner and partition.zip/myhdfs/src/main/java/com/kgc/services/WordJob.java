package com.kgc.services;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * Created by Administrator on 2019/7/4 0004.
 */
public class WordJob {
    public static void main(String[] args) throws Exception {
//        Job job = new Job(new Configuration());
//        job.setJarByClass(WordJob.class);
//
//        job.setMapperClass(WordMapper.class);
//        job.setOutputKeyClass(Text.class);
//        job.setOutputValueClass(LongWritable.class);
//        FileInputFormat.setInputPaths(job,new Path("hdfs://192.168.56.10:9000/hadoop/a.txt"));
//        job.setReducerClass(WordReduce.class);
//        job.setOutputKeyClass(Text.class);
//        job.setOutputValueClass(LongWritable.class);
//        FileOutputFormat.setOutputPath(job,new Path("hdfs://192.168.56.10:9000/hadoop/wcres.txt"));
//        job.waitForCompletion(true);
//        System.out.println("success");
         Job job =Job.getInstance(new Configuration());
         job.setJarByClass(WordJob.class);

         FileInputFormat.setInputPaths(job,new Path("hdfs://192.168.56.10:9000/hadoop/a.txt"));
         FileOutputFormat.setOutputPath(job,new Path("hdfs://192.168.56.10:9000/hadoop/res"));

//         FileInputFormat.setInputPaths(job,new Path("/hadoop/a.txt"));
//         FileOutputFormat.setOutputPath(job,new Path("/hadoop/res1"));

         job.setMapperClass(WordMapper.class);
         job.setReducerClass(WordReduce.class);
         job.setOutputKeyClass(Text.class);
         job.setOutputValueClass(LongWritable.class);
         job.waitForCompletion(true);


    }
}
