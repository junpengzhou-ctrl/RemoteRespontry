package com.kgc.tel;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * Created by Administrator on 2019/7/8 0008.
 */
public class TelReduce extends Reducer<Text,TelWriter,Text,TelWriter> {
    @Override
    protected void reduce(Text key, Iterable<TelWriter> values, Context context) throws IOException, InterruptedException {

    }
}
