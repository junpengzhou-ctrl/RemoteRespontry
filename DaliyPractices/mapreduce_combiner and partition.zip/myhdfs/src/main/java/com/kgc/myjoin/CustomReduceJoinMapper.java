package com.kgc.myjoin;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/**
 * Created by Administrator on 2019/7/5 0005.
 * 用户表分割数据
 */
public class CustomReduceJoinMapper extends Mapper<LongWritable,Text,Text,Text> {
    Text customid= new Text();
    Text customer = new Text();
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String [] datas = value.toString().split(",",-1);
        customid.set(datas[0]);
        customer.set("001"+value.toString());
        context.write(customid,customer);
    }
}
