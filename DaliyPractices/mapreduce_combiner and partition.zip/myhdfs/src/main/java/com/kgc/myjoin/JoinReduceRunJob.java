package com.kgc.myjoin;

/**
 * Created by Administrator on 2019/7/5 0005.
 */
public class JoinReduceRunJob {
    public static void main(String[] args) {

    }
}
