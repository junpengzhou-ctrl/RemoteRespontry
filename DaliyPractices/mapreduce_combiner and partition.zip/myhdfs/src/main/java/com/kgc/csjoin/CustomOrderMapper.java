package com.kgc.csjoin;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;


import java.io.IOException;

/**
 * Created by Administrator on 2019/7/10 0010.
 */
public class CustomOrderMapper  extends Mapper<LongWritable,Text,Text,CustomerOrder>{
    String fileName;
    CustomerOrder co=new CustomerOrder();
    Text cid = new Text();
    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        FileSplit fs = (FileSplit) context.getInputSplit();
        fileName = fs.getPath().getName();
    }

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String [] infos = value.toString().split(",");
        if(fileName.startsWith("order")){
            co.setCustomeId(infos[2]);
            co.setOrderId(infos[0]);
            co.setOrderStatus(infos[3]);
            co.setFlag("1");
            co.setCustomName("");
        }else{
            co.setCustomeId(infos[0]);
            co.setCustomName(infos[1]+" "+infos[2]);
            co.setFlag("0");
            co.setOrderId("");
            co.setOrderStatus("");
        }
        cid.set(co.getCustomeId());
        context.write(cid,co);
    }
}
